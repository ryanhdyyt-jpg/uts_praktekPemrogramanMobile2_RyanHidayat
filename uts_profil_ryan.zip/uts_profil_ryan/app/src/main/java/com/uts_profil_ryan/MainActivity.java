
package com.uts_profil_ryan;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText etName, etUsername, etBio, etContact, etCountry;
    SharedPreferences prefs;

    int purple = Color.rgb(102, 88, 211);
    int dark = Color.rgb(38, 38, 59);
    int background = Color.rgb(245, 245, 250);

    boolean following = false;
    int photoTarget = 0;

    String[] highlightNames = {
            "Travel", "Friends", "Food", "Daily", "New"
    };

    String[] highlightInitials = {
            "TR", "FR", "FO", "DA", "+"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("ProfileData", MODE_PRIVATE);

        showEditProfile();
    }

    // MEMILIH FOTO DARI GALERI
    private void pickImage(int target) {
        photoTarget = target;

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK
                && data != null && data.getData() != null) {

            Uri uri = data.getData();

            try {
                getContentResolver().takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (Exception ignored) {
            }

            prefs.edit()
                    .putString("photo_" + photoTarget, uri.toString())
                    .apply();

            showProfile();

            Toast.makeText(this, "Foto berhasil dipilih",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private String getPhoto(int target) {
        return prefs.getString("photo_" + target, "");
    }

    // KOMPONEN TEKS
    private TextView text(String value, int size, int color,
                          boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);

        if (bold) {
            t.setTypeface(null, Typeface.BOLD);
        }

        return t;
    }

    // BENTUK LATAR MEMBULAT
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private GradientDrawable circleBackground(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setShape(GradientDrawable.OVAL);
        return d;
    }

    private int dp(int value) {
        return (int) (value * getResources()
                .getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(
                width < 0 ? width : dp(width),
                height < 0 ? height : dp(height)
        );
    }

    // KOMPONEN FOTO
    private ImageView makeImage(String uri, int placeholderColor) {
        ImageView img = new ImageView(this);
        img.setBackground(rounded(placeholderColor, 12));
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);

        if (uri != null && !uri.isEmpty()) {
            try {
                img.setImageURI(Uri.parse(uri));
            } catch (Exception ignored) {
            }
        }

        return img;
    }

    // FOTO PROFIL BERBENTUK LINGKARAN
    private FrameLayout makeAvatar(String uri, String initials,
                                   int size) {
        FrameLayout frame = new FrameLayout(this);

        frame.setBackground(circleBackground(purple));
        frame.setClipToOutline(true);

        if (uri != null && !uri.isEmpty()) {
            ImageView img = new ImageView(this);
            img.setImageURI(Uri.parse(uri));
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);

            frame.addView(img, new FrameLayout.LayoutParams(
                    -1, -1
            ));
        } else {
            TextView letter = text(initials, 30, Color.WHITE, true);
            letter.setGravity(Gravity.CENTER);

            frame.addView(letter, new FrameLayout.LayoutParams(
                    -1, -1
            ));
        }

        return frame;
    }

    // HALAMAN EDIT PROFIL
    private void showEditProfile() {
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etUsername = findViewById(R.id.etUsername);
        etBio = findViewById(R.id.etBio);
        etContact = findViewById(R.id.etContact);
        etCountry = findViewById(R.id.etCountry);

        etName.setText(prefs.getString("name", ""));
        etUsername.setText(prefs.getString("username", ""));
        etBio.setText(prefs.getString("bio", ""));
        etContact.setText(prefs.getString("contact", ""));
        etCountry.setText(prefs.getString("country", ""));

        Button btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(v -> {
            prefs.edit()
                    .putString("name",
                            etName.getText().toString().trim())
                    .putString("username",
                            etUsername.getText().toString().trim())
                    .putString("bio",
                            etBio.getText().toString().trim())
                    .putString("contact",
                            etContact.getText().toString().trim())
                    .putString("country",
                            etCountry.getText().toString().trim())
                    .apply();

            Toast.makeText(this, "Profil berhasil disimpan",
                    Toast.LENGTH_SHORT).show();

            showProfile();
        });
    }

    // HALAMAN UTAMA PROFIL
    private void showProfile() {
        String name = prefs.getString("name", "");
        String username = prefs.getString("username", "");
        String bio = prefs.getString("bio", "");
        String contact = prefs.getString("contact", "");
        String country = prefs.getString("country", "");

        if (name.isEmpty()) name = "Your Name";
        if (username.isEmpty()) username = "username";
        if (bio.isEmpty()) bio = "Welcome to my profile!";
        if (country.isEmpty()) country = "Indonesia";

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(background);

        LinearLayout root = column();
        root.setPadding(dp(20), dp(16), dp(20), dp(24));
        scroll.addView(root);

        // JUDUL
        TextView title = text("My Profile", 25, dark, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, params(-1, 48));

        // COVER FOTO
        FrameLayout coverFrame = new FrameLayout(this);
        coverFrame.setBackground(rounded(purple, 18));
        coverFrame.setClipToOutline(true);

        String coverUri = getPhoto(2);

        if (!coverUri.isEmpty()) {
            ImageView coverImage = makeImage(coverUri, purple);
            coverFrame.addView(coverImage,
                    new FrameLayout.LayoutParams(-1, -1));
        } else {
            TextView coverText = text(
                    "MY PROFILE", 22, Color.WHITE, true);
            coverText.setGravity(Gravity.CENTER);
            coverFrame.addView(coverText,
                    new FrameLayout.LayoutParams(-1, -1));
        }

        LinearLayout.LayoutParams coverParams = params(-1, 145);
        coverParams.topMargin = dp(8);
        root.addView(coverFrame, coverParams);

        coverFrame.setOnClickListener(v -> pickImage(2));

        TextView coverHint = text(
                "Ketuk cover untuk mengganti foto",
                11, Color.GRAY, false);
        coverHint.setGravity(Gravity.CENTER);
        root.addView(coverHint, params(-1, 25));

        // FOTO PROFIL
        String initials = getInitials(name);

        FrameLayout avatar = makeAvatar(getPhoto(1), initials, 100);

        LinearLayout.LayoutParams avatarParams = params(100, 100);
        avatarParams.gravity = Gravity.CENTER;
        avatarParams.topMargin = dp(5);
        root.addView(avatar, avatarParams);

        avatar.setOnClickListener(v -> pickImage(1));

        TextView avatarHint = text(
                "Ketuk foto untuk mengganti",
                11, Color.GRAY, false);
        avatarHint.setGravity(Gravity.CENTER);
        root.addView(avatarHint, params(-1, 24));

        // NAMA DAN INFORMASI
        TextView nameView = text(name, 23, dark, true);
        nameView.setGravity(Gravity.CENTER);
        root.addView(nameView, params(-1, -2));

        TextView userView = text(
                "@" + username, 14, purple, false);
        userView.setGravity(Gravity.CENTER);
        root.addView(userView, params(-1, 28));

        TextView bioView = text(bio, 14, dark, false);
        bioView.setGravity(Gravity.CENTER);
        bioView.setPadding(dp(8), dp(4), dp(8), dp(4));
        root.addView(bioView, params(-1, -2));

        TextView countryView = text(
                "Location: " + country, 13, Color.GRAY, false);
        countryView.setGravity(Gravity.CENTER);
        root.addView(countryView, params(-1, 30));

        if (!contact.isEmpty()) {
            TextView contactView = text(
                    "Contact: " + contact, 13, Color.GRAY, false);
            contactView.setGravity(Gravity.CENTER);
            root.addView(contactView, params(-1, 28));
        }

        // TOMBOL EDIT
        Button edit = new Button(this);
        edit.setText("Edit Profile");
        edit.setAllCaps(false);
        edit.setTextColor(Color.WHITE);
        edit.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(purple));

        LinearLayout.LayoutParams editParams = params(-1, 48);
        editParams.setMargins(dp(5), dp(12), dp(5), dp(20));
        root.addView(edit, editParams);

        edit.setOnClickListener(v -> showEditProfile());

        // STATISTIK
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setGravity(Gravity.CENTER);
        stats.setBackground(rounded(Color.WHITE, 24));
        stats.setPadding(dp(4), dp(14), dp(4), dp(14));

        addStat(stats, "205", "Posts");
        addStat(stats, "205K", "Followers");
        addStat(stats, "870", "Following");

        LinearLayout.LayoutParams statsParams = params(-1, 95);
        statsParams.bottomMargin = dp(12);
        root.addView(stats, statsParams);

        // FOLLOW
        Button follow = new Button(this);
        follow.setText(following ? "Following" : "Follow");
        follow.setAllCaps(false);
        follow.setTextColor(Color.WHITE);
        follow.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(purple));

        root.addView(follow, params(-1, 48));

        follow.setOnClickListener(v -> {
            following = !following;
            follow.setText(following ? "Following" : "Follow");

            Toast.makeText(this,
                    following ? "Berhasil Follow" : "Unfollow berhasil",
                    Toast.LENGTH_SHORT).show();
        });

        // HIGHLIGHTS
        TextView highlights = text("Highlights", 22, dark, true);
        LinearLayout.LayoutParams highlightTitleParams =
                params(-1, 45);
        highlightTitleParams.topMargin = dp(12);
        root.addView(highlights, highlightTitleParams);

        LinearLayout circles = new LinearLayout(this);
        circles.setOrientation(LinearLayout.HORIZONTAL);
        circles.setGravity(Gravity.CENTER);
        circles.setPadding(0, dp(4), 0, dp(8));

        for (int i = 0; i < highlightNames.length; i++) {
            final int target = i + 9;

            LinearLayout item = column();
            item.setGravity(Gravity.CENTER);

            FrameLayout circle = new FrameLayout(this);
            circle.setBackground(circleBackground(Color.WHITE));
            circle.setClipToOutline(true);

            String uri = getPhoto(target);

            if (!uri.isEmpty()) {
                ImageView photo = makeImage(uri, Color.WHITE);
                circle.addView(photo,
                        new FrameLayout.LayoutParams(-1, -1));
            } else {
                TextView letter = text(
                        highlightInitials[i], 16, purple, true);
                letter.setGravity(Gravity.CENTER);
                circle.addView(letter,
                        new FrameLayout.LayoutParams(-1, -1));
            }

            LinearLayout.LayoutParams circleParams = params(52, 52);
            circleParams.gravity = Gravity.CENTER;
            item.addView(circle, circleParams);

            circle.setOnClickListener(v -> pickImage(target));

            TextView caption = text(
                    highlightNames[i], 11, dark, false);
            caption.setGravity(Gravity.CENTER);

            item.addView(caption, params(-1, 28));

            circles.addView(item,
                    new LinearLayout.LayoutParams(0, -2, 1f));
        }

        root.addView(circles, params(-1, 90));

        // GALERI PHOTOS
        TextView photosTitle = text("Photos", 22, dark, true);

        LinearLayout.LayoutParams photosTitleParams =
                params(-1, 42);
        photosTitleParams.topMargin = dp(8);
        root.addView(photosTitle, photosTitleParams);

        for (int rowIndex = 0; rowIndex < 2; rowIndex++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);

            for (int colIndex = 0; colIndex < 3; colIndex++) {
                final int index = rowIndex * 3 + colIndex;
                final int target = index + 3;

                LinearLayout cell = column();
                cell.setGravity(Gravity.CENTER);

                String uri = getPhoto(target);

                FrameLayout photoFrame = new FrameLayout(this);
                photoFrame.setBackground(
                        rounded(Color.rgb(225, 221, 244), 10));
                photoFrame.setClipToOutline(true);

                if (!uri.isEmpty()) {
                    ImageView photo = makeImage(
                            uri, Color.rgb(225, 221, 244));

                    photoFrame.addView(photo,
                            new FrameLayout.LayoutParams(-1, -1));
                } else {
                    TextView addIcon = text(
                            "+", 32, purple, true);
                    addIcon.setGravity(Gravity.CENTER);

                    photoFrame.addView(addIcon,
                            new FrameLayout.LayoutParams(-1, -1));
                }

                LinearLayout.LayoutParams photoParams =
                        new LinearLayout.LayoutParams(
                                -1, dp(110));

                photoParams.setMargins(
                        dp(4), dp(4), dp(4), dp(4));

                cell.addView(photoFrame, photoParams);

                photoFrame.setOnClickListener(
                        v -> pickImage(target));

                TextView caption = text(
                        uri.isEmpty()
                                ? "Tambah Foto"
                                : "Ganti Foto",
                        11, dark, false);

                caption.setGravity(Gravity.CENTER);
                cell.addView(caption, params(-1, 25));

                row.addView(cell,
                        new LinearLayout.LayoutParams(0, -2, 1f));
            }

            LinearLayout.LayoutParams rowParams =
                    params(-1, 145);
            root.addView(row, rowParams);
        }

        setContentView(scroll);
    }

    // MENGAMBIL INISIAL NAMA
    private String getInitials(String name) {
        String[] words = name.trim().split("\\s+");

        if (name.trim().isEmpty()) {
            return "U";
        }

        if (words.length == 1) {
            return words[0].substring(0, 1).toUpperCase();
        }

        return (words[0].substring(0, 1)
                + words[words.length - 1].substring(0, 1))
                .toUpperCase();
    }

    // STATISTIK PROFIL
    private void addStat(LinearLayout parent,
                         String number, String label) {
        LinearLayout item = column();
        item.setGravity(Gravity.CENTER);

        TextView n = text(number, 20, dark, true);
        n.setGravity(Gravity.CENTER);
        item.addView(n);

        TextView l = text(label, 13, Color.GRAY, false);
        l.setGravity(Gravity.CENTER);
        item.addView(l);

        parent.addView(item,
                new LinearLayout.LayoutParams(0, -2, 1f));
    }
}
